const MAX_BODY = 18 * 1024 * 1024;
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const send = (statusCode, obj) => ({ statusCode, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, body: JSON.stringify(obj) });
export async function handler(event) {
  if (event.httpMethod !== 'POST') return send(405, { code: 'method', error: 'POST only' });
  const key = process.env.GEMINI_API_KEY;
  if (!key) return send(503, { code: 'not_configured', error: 'GEMINI_API_KEY is missing' });
  if (!event.body || event.body.length > MAX_BODY) return send(413, { code: 'too_large' });
  let body;
  try { body = JSON.parse(event.body); } catch { return send(400, { code: 'invalid_json' }); }
  if (!Array.isArray(body.messages) || body.messages.length < 1 || body.messages.length > 22) return send(400, { code: 'invalid_messages' });
  const contents = [];
  for (const message of body.messages) {
    if (!message || !['user', 'assistant'].includes(message.role) || typeof message.content !== 'string' || message.content.length > 45000) return send(400, { code: 'invalid_messages' });
    contents.push({ role: message.role === 'assistant' ? 'model' : 'user', parts: [{ text: message.content }] });
  }
  if (body.images !== undefined) {
    if (!Array.isArray(body.images) || body.images.length > 3) return send(400, { code: 'image_rejected' });
    for (const img of body.images) {
      if (!img || !['image/jpeg', 'image/png', 'image/webp'].includes(img.mimeType) || typeof img.data !== 'string' || img.data.length > 5600000 || !/^[A-Za-z0-9+/]+={0,2}$/.test(img.data)) return send(400, { code: 'image_rejected' });
      contents[contents.length - 1].parts.push({ inline_data: { mime_type: img.mimeType, data: img.data } });
    }
  }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 45000);
  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`;
    const resp = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key }, body: JSON.stringify({ contents, generationConfig: { temperature: 0.6, maxOutputTokens: 4096, ...(body.json ? { responseMimeType: 'application/json' } : {}) } }), signal: controller.signal });
    if (!resp.ok) return send(resp.status === 429 ? 429 : 502, { code: resp.status === 429 ? 'rate_limited' : 'provider_error', error: 'AI provider request failed' });
    const result = await resp.json();
    const text = (result.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('').trim();
    if (!text) return send(502, { code: 'empty_response' });
    if (body.json) {
      let parsed;
      try { parsed = JSON.parse(text); } catch { return send(502, { code: 'invalid_ai_json' }); }
      return send(200, { text, json: parsed });
    }
    return send(200, { text });
  } catch (e) { return send(502, { code: e?.name === 'AbortError' ? 'timeout' : 'provider_error' }); }
  finally { clearTimeout(timeout); }
}
